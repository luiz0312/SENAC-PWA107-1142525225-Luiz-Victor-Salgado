import {Link} from 'react-router-dom';
import {useState} from 'react';

function Cadastro (){

    const [razaoSocial, setRazao]=useState('');
    const [Endereco, setEndereco]=useState('');
    const [CNPJ, setCNPJ]=useState('');
    
    const[Dados, setDados]=useState({
        Razaox:"------------", 
        Saldox:"0",
        CNPJx:"00.000.000/0001-00"
    })

    function Registro(eventox){
        eventox.preventDefault();

        if(CNPJ === ''){
            window.alert('O campo de CNPJ não pode ficar vazio!!')
        
        }else if(CNPJ.length !== 14){
            window.alert('O CNPJ precisa ter 14 digitos!!')
        
        }else{
            setDados({
            Razaox:razaoSocial,
            Enderecox:Endereco,
            CNPJx:CNPJ
        })
        }
    }

    return(
        <div align='left'>
            <h1 align='center'>Cadastro </h1>

            <form onSubmit={Registro} align='center'>
            
            <label><strong>Razão Social:</strong></label><br/>
            <input placeholder='Digite sua Razão Social' value={razaoSocial} onChange={(evento)=>setRazao(evento.target.value)}/><br/>

            <label><strong>Endereço:</strong></label><br/>
            <input placeholder='Digite seu Endereço' value={Endereco} onChange={(evento)=>setEndereco
            (evento.target.value)}/><br/>

            <label><strong>CNPJ:</strong></label><br/>
            <input placeholder='CNPJ usuario' value={CNPJ} onChange={(evento)=>setCNPJ(evento.target.value)}/><br/>

            <button type='submit'>Cadastrar</button><br/>
                <br/>
                <div>
                    <span>
                        Razão Social:{Dados.Razaox}
                    </span><br/>
                    <span>
                        Endereço do Usuario:
                        {Dados.Enderecox}
                    </span><br/>
                    <span>
                        CNPJ do Usuario:
                        {Dados.CNPJx}
                    </span>
                    
                </div>  
                </form>
                </div>
    );
}
export default Cadastro;