import {Link} from 'react-router-dom';
import {useState} from 'react';

function SobreNos(){
    return(
        <div>
            <h1>EMPRESA DE ENTREGAS L.V.S</h1>
            <h3>ENTREGAS E FRETE</h3>
        </div>

    );
}
export default SobreNos;