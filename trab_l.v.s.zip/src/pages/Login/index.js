import {Link} from 'react-router-dom';
import {useState} from 'react';

function Login(){

const [IDusu, setIDusu]=useState('');
const [Senha, setSenha]=useState('');

const [Dados, setDados]=useState({
    IDusux:"-------------",
    Senhax:"-------------"

})

    function Registro(eventox){
        eventox.preventDefault();
        
        var ID = [
            'user123'
            
         ]
        
        var senha = [
            123456
        ]
        var cont = 0;

         ID.forEach((item)=>{

                if(item == IDusu){
                    window.alert(' correto!!' + "\t" + IDusu)
                    cont ++
        
                }else{
                    window.alert('não cadastrado')
                }
        })

        senha.forEach((item)=>{
            if(item == Senha){
                window.alert('Senha correta!!')
                cont ++
            }else{
                window.alert('incorreta!!')
            }
        })

        if(cont == 2){
            window.alert('Bem Vindo')
             setDados({
            IDusux: IDusu,
            Senhax: Senha
            
        })
        }
       
        }
        return(
        <div align='left' >
            <h1 align ='center'>Entrada </h1>
            <p>Id certo do Usuario: user123 </p>
            <p>Senha correta: 123456</p>

            <form onSubmit={Registro} align='center'>
                
            <label>
                <strong>Nome:</strong></label><br/>
                 <input placeholder='Digite seu Id' value={IDusu} onChange={(evento)=>setIDusu(evento.target.value)}/><br/><br/>

               <label>
                <strong>Senha:</strong></label><br/>
                 <input placeholder='Digite sua Senha' value={Senha} onChange={(evento)=>setSenha(evento.target.value)}/>
               <br/>

                <button type='submit'>Cadastro</button><br/>
                <br/>

                <div>
                    <span>
                        ID do Usuario:{Dados.IDusux}
                    </span><br/>
                    <span>
                        Senha do Usuario:
                        {Dados.Senhax}
                    </span><br/>
                </div>  
                </form> 
        </div>
   
   );
    
}
export default Login;