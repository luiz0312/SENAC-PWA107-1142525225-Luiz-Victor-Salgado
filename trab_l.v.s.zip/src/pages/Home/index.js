import {Link} from 'react-router-dom';
function Home (){
    return(
        <div>
            <h1 >l.v.s</h1>
            <p>abas acima para navegação.</p>
            
            
        </div>
    );

}
export default Home;