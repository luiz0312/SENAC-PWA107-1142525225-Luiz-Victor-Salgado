function Erro(){
    return(
        <div>
            <h1>erro </h1>
        </div>
    )
}
export default Erro;