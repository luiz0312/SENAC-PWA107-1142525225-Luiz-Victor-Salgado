import {Link} from 'react-router-dom';
import {useState} from 'react';

function Frete(){

    const [Peso, setPeso]=useState('');
    const [Destino, setDestino]=useState('');
    const [Kms, setKms]=useState('');
    const [valorFrete, setValor]=useState('');

    const [Dados, setDados]=useState({
    Pesox:"-------------",
    Destinox:"-------------",
    valorFretex:"-------------"
    
})
 var cont = 0;

function calcularFrete(dados){
    dados.preventDefault();

    var destinos = [
        'São José ',
        'São januario',
        'Santos',
        'Itapecerica ',
        'São tome'

    ]

    destinos.forEach((item)=>{

        if(item === 'São José ' && item === Destino){
            setKms(446);

        }else if(item === 'São januario' && item === Destino){
            setKms(10);
        
        }else if(item === 'Santos' && item === Destino){
            setKms(79);

        }else if(item === 'Itapecerica ' && item === Destino){
            setKms(28);

        }else if(item === 'São tome' && item === Destino){
            setKms(691);

        }
    })

    destinos.forEach((item)=>{


        if(item != Destino){
            cont += 1;
           
        }
        
    })
        if(Destino === ''){
            window.alert('ERRO!! Você deve inserir um destino!!')
        }

        if(Peso === ''){
            window.alert('ERRO!!  inserir um peso para que o frete possa ser calculado!!')
        }
        if(cont === 5){
            window.alert('Cidade não disponivel !!')
            window.alert('Cidades disponiveis: São José do Rio Preto, São Paulo, Santos, Itapecerica da Serra e São Manuel')
        }

        setValor(Kms * 2.5)
       
        setDados({
            Pesox: Peso,
            Destinox: Destino,
            valorFretex: valorFrete
            
        });
}
    
        return(
        <div align='left'>
            <h1 align ='center' >Cálculo </h1><br/>

            <form onSubmit={calcularFrete} align='center' >
                
            <label>
                <strong>Peso(toneladas):</strong></label><br/>
                 <input placeholder='Peso' value={Peso} onChange={(evento)=>setPeso(evento.target.value)}/><br/><br/>
          
            <label>
                <strong>Destino</strong></label><br/>
                <input placeholder='Destino' value={Destino}
                onChange={(evento)=>setDestino (evento.target.value)}/><br/>

                <button type='submit'>Calcular</button>
                <br/><br/>

                <div>
                    <span>
                        <strong>Peso(toneladas):</strong>{Dados.Pesox}
                    </span><br/>
                    
                    <span>
                        <strong>Destino:</strong>
                        {Dados.Destinox}
                    </span><br/>
                    
                    <span>
                        <strong>Valor Frete:</strong> {Dados.valorFretex}
                    </span><br/>
   
                </div>  

            </form> 
        </div>
   
   );
    
}
export default Frete;