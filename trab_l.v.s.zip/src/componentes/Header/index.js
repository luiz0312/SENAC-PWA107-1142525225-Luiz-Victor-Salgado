import {Link} from 'react-router-dom'
import './style.css'
function Header(){
    
    return(
        <header>
            l.v.s
        <div className='menu'><br/>

        <Link to="/frete">Frete</Link>&nbsp;
        <Link to="/login" >Login</Link>&nbsp;
        <Link to="/cadastro">Cadastro</Link>&nbsp;
        <Link to="/sobrenos">Sobre Nós</Link>
        <Link to="/">Home</Link>
    
            </div>
        </header>
    );
}
export default Header;